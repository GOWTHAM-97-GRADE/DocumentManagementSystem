export const environment = {
    production: true,
    apiUrl: 'https://yourapi.domain.com/api'
  };
  